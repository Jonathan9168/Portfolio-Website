package com.Jonathan;

/*Author: Jonathan A
* Date:30/01/2021
* Description: OOP Bill Manager. Allows user to create accounts and track their spending.*/

import java.io.*;

public class Main
{
    public static void main(String[] args) throws IOException
    {
        Menus.check();
    }
}
