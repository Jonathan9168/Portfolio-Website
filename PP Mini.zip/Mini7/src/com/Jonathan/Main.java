package com.Jonathan;
/*
AUTHOR Jonathan
DATE 30 October 2020

This is a simpler take on the game show pointless. It allows users to start new games and answer a series of questions.
It allows users to print fun facts , save scores to a text file which generates a summary and also view previous saves.

Valid Answers:

Full answer as printed in question or phrases. E.g. Cristiano Ronaldo or Ronaldo are valid.
*/

/*These are imports of utilities*/
import java.io.*;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

/*
Question Record.This is all the data that is stored for a created question.
A record is also created for the players points.
*/

class questionRecords
{
    int playerpoints;
    String question;
    String qca1;
    String qca1a;
    String qca2;
    String qca2a;
    String wrong;
    int qca1points;
    int qca2points;
}

public class Main
{
    public static void main(String[] args)
    {
        MainMenu();
    }

    /* Main Menu which lets the user choose what they want to do.*/

    public static void MainMenu()
    {
        Scanner scanner = new Scanner(System.in);

        final String n = "N";
        final String p = "P";
        final String v = "V";
        final String q = "Q";

        String choice;

        System.out.println("[N] New Game");
        System.out.println("[P] Print a fun fact");
        System.out.println("[V] View Previous Save");
        System.out.println("[Q] Quit");

        choice = scanner.nextLine().toUpperCase();

        if (choice.equals(n))
        {
            QuestionDetails();
        }
        else if (choice.equals(p))
        {
            funFact();
        }
        else if (choice.equals(v))
        {
            try
            {
                LoadSave();
            } catch (IOException e)
            {
               System.out.println("I don't think that file exists.");
               MainMenu();
            }
        }
        else if (choice.equals(q))
        {
            System.exit(0);
        }
        else
        {
            System.out.print("PLEASE ENTER A VALID OPTION!\n");
            MainMenu();
        }
    }

    /* This method initialises questions as well as player points.*/

    public static void QuestionDetails()
    {
        questionRecords points = new questionRecords();

        setplayerpoints(points);

        questionRecords q1 = createQuestion("FIRST 20 ELEMENTS OF THE PERIODIC TABLE\n","Nitrogen","nitrogen",
                "Phosphorus","phosphorus","Barium",13,0);

        questionRecords q2 = createQuestion("WAYS TO COOK OR SERVE EGGS\n","A La Florientine","a la Florientine",
                "Creole","creole","Pléu",1,0);

        questionRecords q3 = createQuestion("COUNTRIES THAT BORDER TURKEY \n","Iraq","iraq",
                "Azerbaijan","azerbaijan","Spain",25,0);

        questionRecords q4 = createQuestion("GOALKEEPERS WHO HAVE PLAYER FOR ENGLAND\n" +
                        "No unused subs- Any England Goalie from 1966 to 2011 \n","David Seaman","Seaman",
                "Jimmy Rimmer","Rimmer","Paul Scholes",65,0);

        questionRecords q5 = createQuestion("AMERICAN WIMBLEDON WINNERS\n" +
                        "Men or women, up to 2010. Must be from the USA. \n","Venus Williams","Venus",
                "Lindsay Davenport","Lindsay","Naomi Osaka",29,1);

        questionRecords q6 = createQuestion("TYPES OF PROGRAMMING\n","Object Oriented","object oriented",
                "Functional","functional","Transformative",53,25);

        questionRecords q7 = createQuestion("BEST ANIMATED FEATURE OSCAR WINNER\n" +
                        "Any from 2002-2011 winner of the 'Best Animated Feature' at the Oscars.\n","Shrek","shrek",
                "Up","up","Madagascar",23,11);

        questionRecords q8 = createQuestion("TYPES OF TOOLS\n","Screwdriver","screwdriver",
                "Mattock","mattock","Burrel",89,0);

        questionRecords q9 = createQuestion("EUROPEAN MONARCHS\n" +
                        "Any reigning king or queen of a European country. \n","Queen Elizabeth II","Elizabeth",
                "Joan Enric","Enric","Michael Of Normandy",95,0);

        questionRecords q10 = createQuestion("UK Cities beginning with 'B'\n","Bath","bath",
                "Bangor","bangor","Blaston",35,3);

        questionRecords[] QuestionBank = {q1,q2,q3,q4,q5,q6,q7,q8,q9,q10}; /*Questions are stored in an array of type questionRecords*/
        int[] p = {}; /*This array will go on to store the points the user scored for each question */
        int round = 1; /*Initialisation of round counter. This helps distinguish rounds between each question.*/
        int QuestionTracker = 0; /*Initialisation of QuestionTracker which keeps track of the index of the question array
        that is currently being answered so the index doesn't go out of bound of question array.*/
        whatQuestion(QuestionBank,getplayerpoints(points),p,round,QuestionTracker);
    }

    /*This method gets the next question in the QuestionBank array, this question is sent to
    PrintQuestion to be printed */
    public static void whatQuestion(questionRecords[] QuestionBank, int points, int[] p,int round,int QuestionTracker)
    {

        printQuestion(QuestionBank,QuestionBank[QuestionTracker],points,p,round,QuestionTracker);

    }

    /*This method  prints a random fact. It chooses an element in a random index of the random fact array and prints it.*/
    public static void funFact()
    {
        Random gen = new Random();
        int randNum;

        String[] factArray = {"Your nostrils work one at a time.","Copper door knobs are self-disinfecting.","Pineapple works as a natural meat tenderizer."
        , "North Korea and Cuba are the only places you can't buy Coca-Cola.","The entire world's population could fit inside Los Angeles.",
                "Banging your head against a wall for one hour burns about 150 calories."};

        randNum = gen.nextInt(factArray.length);

        System.out.println(factArray[randNum] + "\n");

        MainMenu();
    }

    /*This method creates a new question. It takes all the data that's need for a given question as an argument an returns this question.*/
    public static questionRecords createQuestion (String question,String qca1,String qca1a,String qca2,String qca2a,String wrong,int qca1apoints,int qca2apoints)
    {
        questionRecords q = new questionRecords();

        q.question = question;
        q.qca1 = qca1;
        q.qca1a = qca1a;
        q.qca2 = qca2;
        q.qca2a = qca2a;
        q.wrong = wrong;
        q.qca1points = qca1apoints;
        q.qca2points = qca2apoints;

        return q;
    }

    /*Setters and getters for player points*/
    public static void setplayerpoints(questionRecords q){q.playerpoints = 0;}
    public static int getplayerpoints(questionRecords q){return q.playerpoints;}

    /*Getters for all questions*/
    public static String getquestion(questionRecords q){return q.question;}
    public static String getqca1(questionRecords q){return q.qca1;}
    public static String getqca1a(questionRecords q){return q.qca1a;}
    public static String getqca2(questionRecords q){return q.qca2;}
    public static String getqca2a(questionRecords q){return q.qca2a;}
    public static String getqwrong(questionRecords q){return q.wrong;}
    public static int getqca1points(questionRecords q){return q.qca1points;}
    public static int getqca2points(questionRecords q){return q.qca2points;}

    /*Method that prints the question and possible options.A random number is generated to print the questions's options
    * in different orders to add some variety*/
    public static void printQuestion(questionRecords[] QuestionBank, questionRecords q, int points, int[] p,int round,int QuestionTracker)
    {
        String answer;
        Scanner scanner = new Scanner(System.in);
        Random gen = new Random();
        int y = gen.nextInt(QuestionBank.length);

        if (y == 0)
        {
            System.out.println("");
            System.out.println("ROUND: " + round + "\n");
            System.out.println(getquestion(q));
            System.out.println("A) " + getqca1(q));
            System.out.println("B) " + getqwrong(q));
            System.out.println("C) " + getqca2(q));
        }
        else if (y < 3)
        {
            System.out.println("");
            System.out.println("ROUND: " + round + "\n");
            System.out.println(getquestion(q));
            System.out.println("A) " + getqwrong(q));
            System.out.println("B) " + getqca2(q));
            System.out.println("C) " + getqca1(q));
        }
        else
        {
            System.out.println("");
            System.out.println("ROUND: " + round + "\n");
            System.out.println(getquestion(q));
            System.out.println("A) " + getqca2(q));
            System.out.println("B) " + getqca1(q));
            System.out.println("C) " +  getqwrong(q));
        }

        answer = scanner.nextLine();

        int x = scoredPoints(q, answer); /*Variable which stores how much points a user scored from a question*/
        int newpoints = trackPoints(x,points); /*Variable which stores the updated points after a question is answered*/
        p = pointsAppend(p,x); /*replaces the old points array with a new array with latest points added to it from latest question answered.*/
        summary(QuestionBank,q,answer,newpoints,p,round,QuestionTracker);
    }

    /*This method takes the user's current points and adds the points they scored from the question just answered*/
    public static int trackPoints(int scored, int points)
    {
        points += scored;

        return points;
    }

    /*This method returns the points scored by a user depending on an answer they entered.
    Their answer is compared to predefined answers.*/
    public static int scoredPoints(questionRecords q , String answer)
    {
        if (answer.contains(getqca1(q))|answer.contains(getqca1a(q)))
        {
            return getqca1points(q);
        }
        else if (answer.contains(getqca2(q))|answer.contains(getqca2a(q)))
        {
            return getqca2points(q);
        }
        else
        {
            return 100;
        }
    }

    /*This method appends a new element (points scored from a question) to an array.
    It does this by duplicating the original array and increasing its length by one.
    * This new element is then added to the end of the array.*/

    public static int[] pointsAppend(int[] newArray, int element)
    {
        newArray  = Arrays.copyOf(newArray, newArray.length + 1);
        newArray[newArray.length - 1] = element;

        return newArray;
    }

    /*This method prints a summary to the user after they've answered a question. They are then asked if they want to
    * continue. If so a new question is picked. If not they will have an option to save their scores.*/
    public static void summary(questionRecords[] QuestionBank, questionRecords q, String answer, int newpoints, int[] p, int round, int QuestionTracker)
    {
        Scanner scanner = new Scanner(System.in);
        final String flag = "N";
        String decision;

        if (answer.contains(getqca1(q))|answer.contains(getqca1a(q)))
        {
            System.out.println("You chose a correct answer.\n");
            System.out.println( getqca1(q) + " scored " +getqca1points(q) + " points.");
            System.out.println( getqca2(q) + " scored " + getqca2points(q) + " points.");
            System.out.println( getqwrong(q) + " was the incorrect answer and scored 100 points. \n");
            System.out.println("You now have " + newpoints + " points.\n");
        }
        else if (answer.contains(getqca2(q))|answer.contains(getqca2a(q)))
        {
            if(getqca2points(q)==0)
            {
                System.out.println("You chose a pointless answer!\n");
                System.out.println( getqca1(q) + " scored " +getqca1points(q) + " points.");
                System.out.println( getqca2(q) + " scored " + getqca2points(q) + " points.");
                System.out.println( getqwrong(q) + " was the incorrect answer and scored 100 points. \n");
                System.out.println("You still have " + newpoints + " points.\n");
            }
            else
            {
                System.out.println("You chose the lowest scoring answer.\n");
                System.out.println( getqca1(q) + " scored " +getqca1points(q) + " points.");
                System.out.println( getqca2(q) + " scored " + getqca2points(q) + " points.");
                System.out.println( getqwrong(q) + " was the incorrect answer and scored 100 points. \n");
                System.out.println("You now have " + newpoints + " points.\n");
            }
        }
        else
        {
            System.out.println("You chose an incorrect answer.\n");
            System.out.println( getqca1(q) + " scored " +getqca1points(q) + " points.");
            System.out.println( getqca2(q) + " scored " + getqca2points(q) + " points.");
            System.out.println( getqwrong(q) + " was the incorrect answer and scored 100 points. \n");
            System.out.println("You now have " + newpoints + " points.\n");
        }

        System.out.print("Do you want to continue? Y/N \n");
        System.out.print("");

        decision = scanner.nextLine().toUpperCase();

        /*Loop checks if the user wants to continue*/
        while (!decision.equals(flag))
        {
            QuestionTracker +=1;

            if (QuestionTracker > QuestionBank.length-1)
            {
                System.out.println("\nYou've answered all the questions!\n");
                scoreBubbleSorter(p,round);
            }
            else
            {
                round +=1;
                whatQuestion(QuestionBank, newpoints,p,round,QuestionTracker);
            }
        }

        scoreBubbleSorter(p,round);

    }

    /*This method swaps adjacent elements of an array if the larger element is before the smaller element*/

    public static void swap(int[] points , int i)
    {
        int temp = points[i];
        points[i] = points[i+1];
        points[i+1] = temp;
    }

    /*This method uses bubble sort to order the points a user has scored from their answered questions in ascending order
    * This means lower scoring answers are ranked 1st as they're closest to being pointless.*/

    /*If the user want's to save their scores, they have an option to write their results to a file that is named what
    * they want.*/
    public static void scoreBubbleSorter(int [] points,int round)
    {
        boolean sorted = false;

        while (!sorted)
        {
            sorted = true;

            for (int i = 0; i < points.length - 1; i++)
            {
                if (points[i] > points[i + 1])
                {
                    swap(points,i);
                    sorted = false;
                }
            }
        }

        System.out.println("Ranking of your lowest scoring answers. \n");

        /*For loop which prints a list of scored answers in ascending order*/

        for (int i=0; i< points.length;i++)
        {
            System.out.print((i+1)+" : "+ points[i]+" points. \n");
        }

        try
        {
            String answer;
            final String flag1 = "Y";
            final String flag2 = "N";

            Scanner scanner = new Scanner(System.in);

            System.out.println("\nDo you want to save your scores? Please type 'Y' FOR YES or 'N' FOR NO");
            answer = scanner.nextLine().toUpperCase();

            if (answer.equals(flag1))
            {
                 int pointTotal = 0;

                 for (int i = 0; i < points.length;i++)
                 {
                     pointTotal += points[i];
                 }

                 int pointless = 0;
                 int incorrect = 0;
                 int correct = 0;

                 /*For loop parses sorted array linearly and adds to pointless total if element in index is zero; adds to
                 * incorrect if 100 and adds to correct if not pointless or incorrect.*/
                for (int i = 0; i < points.length;i++)
                {
                    if (points[i] == 0)
                    {
                        pointless += 1;
                    }
                    else if (points[i] == 100)
                    {
                        incorrect += 1;
                    }
                    else
                    {
                        correct += 1;
                    }
                }

                writeFile(points,pointTotal,round,pointless,incorrect,correct);
            }
            else if (answer.equals(flag2))
            {
                MainMenu();
            }
            else
                {
                    System.out.println("You must've typed something erroneous.Please try again.\n");
                    scoreBubbleSorter(points,round);
                }
        }
        catch (IOException e)
        {
            System.out.println("Something seems to have gone wrong.");
        }
    }

    /*This method creates a new text file that is named by the user.It then writes all the information about the user's
    * scored points to the file along with the bubble sorted ranked order of points they scored from each question
    * highest to lowest*/
    public static void writeFile(int[] points, int pointTotal,int round,int pointless,int incorrect, int correct)
            throws IOException
    {
        Scanner scanner = new Scanner(System.in);
        String answer;

        System.out.print("Time to save your scores! What would you like to name your file?\n");
        answer = scanner.nextLine();

        PrintWriter outputStream = new PrintWriter(new FileWriter(answer + ".txt"));

        outputStream.println("You played a total of: " + round + " round(s)");
        outputStream.println("You scored a total of: " + pointTotal + " point(s)");
        outputStream.println("---------------------------------------------------------------------");
        int averagepoints = pointTotal/round;
        double averagecorrect = (((double)correct + (double)pointless) / (double)round) * 100;

        outputStream.println("That's an average of: " + averagepoints + " point(s) per round");
        outputStream.println("You chose a correct answer: " + averagecorrect + "%" + " of the time");
        outputStream.println("---------------------------------------------------------------------");
        outputStream.println("You chose a total of: " + correct + " correct answer(s)");
        outputStream.println("You chose a total of: " + incorrect + " incorrect answer(s)");
        outputStream.println("You chose a total of: " + pointless + " pointless answer(s)");

        outputStream.println("----------------------------------------------------------------------");
        outputStream.println("           Ranking of points obtained in ascending order             ");
        outputStream.println("----------------------------------------------------------------------");

        /*For loop that prints what is in each index of the bubble sorted points array*/
        for (int i = 0; i < points.length; i++)

        {
            outputStream.println("----------------------------------------------------------------------");
            outputStream.println("Lowest scoring answer " + (i+1) + " scored: " + "|" + points[i] + "|" + " point(s)");
            outputStream.println("----------------------------------------------------------------------");
        }
        outputStream.close();
        readFile(answer);
    }

    /*This method prints a confirmation line by line of everything that was written to the file.*/
    public static void readFile(String response)
            throws IOException
    {
        BufferedReader inputStream = new BufferedReader(new FileReader( response +".txt"));

        String written = inputStream.readLine();
        System.out.println("");

        while (written != null)
        {
            System.out.println("'" + written + "'" + " was stored in the file " + response + ".txt");
            written = inputStream.readLine();
        }

        inputStream.close();
        System.out.println("");

        MainMenu();
    }

    /*This method prints a previous saved file or a prior game when option V is chosen at the main menu. The user enters
     * the name of the file to load.*/
    public static void LoadSave()
            throws IOException
    {
        Scanner scanner = new Scanner(System.in);
        String file;

        System.out.println("What file do you want to view?");
        file = scanner.nextLine();
        System.out.println("");

        BufferedReader inputStream = new BufferedReader(new FileReader( file +".txt"));

        String line = inputStream.readLine();

        while (line != null)
        {
            System.out.println(line);
            line = inputStream.readLine();
        }
        System.out.println("");
        MainMenu();
    }
}
